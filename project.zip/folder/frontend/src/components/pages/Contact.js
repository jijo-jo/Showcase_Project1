import React from 'react';

const Contact = () => {
    return (
        <div className="content-wrapper about-us">
            <h2 className="feature-title">Contact</h2>
            <p>Phone number:9846098276</p>
            <p>Email:indiantimes@gmail.com</p>
            <p>Contact us for any issues</p>
        </div>
    )
}

export default Contact;