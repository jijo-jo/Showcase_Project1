import React from 'react';

const Homepage = () => {
    return (        
        <div className="banner">
            <img className="banner-image" src="./images/banner.jpg" alt=""/>
        </div>        
    )
}

export default Homepage;