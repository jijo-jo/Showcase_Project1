import React from "react";


export default function Nomatch(){

    return(<h2>Nothing</h2>)
}