import React from 'react';

const AboutUs = () => {
    return (
        <div className="content-wrapper about-us">
            <h2 className="feature-title">About Us</h2>
            <p>Above 20 years of Experience an All kinds of watches are available</p>
            <p></p>
        </div>
    )
}

export default AboutUs;